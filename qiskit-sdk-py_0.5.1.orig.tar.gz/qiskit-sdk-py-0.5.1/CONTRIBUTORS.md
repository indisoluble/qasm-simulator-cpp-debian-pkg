Contributors (alphabetically)
=============================

QISKit is the result of the efforts of many people - many thanks to everyone
involved in the project:

* Ismail Yunus Akhalwaya
* Luciano Bello
* Jim Challenger
* Andrew Cross
* Vincent Dwyer
* Mark Everitt
* Ismael Faro
* Jay Gambetta
* Juan Gomez
* Ali Javadi-Abhari
* Yunho Maeng
* Paco Martin
* Antonio Mezzacapo
* Diego Moreda
* Jesus Perez
* Russell Rundle
* Todd Tilma
* John Smolin
* Erick Winston
* Chris Wood

If you [contribute to the project](CONTRIBUTING.rst), you are welcome to include
your name in this list.
